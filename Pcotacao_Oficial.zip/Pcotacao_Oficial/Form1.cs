﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Pcotacao_Oficial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public object ListBoxOutput { get; private set; }
        private void Button1_Click(object sender, EventArgs e)
        {
            double[,] notebooks = new double[3, 3];
            string aux = "";
            double mediaprecos = 0.0;

            listBox1.Items.Clear();

            for (int i = 0; i < 3; i++)
            {
                mediaprecos = 0;
                for (int j = 0; j < 3; j++)
                {
                    
                    aux = Interaction.InputBox($"Digite o preço do {j + 1} notebook:", $"{i + 1}º notebook: ");

                    if (!Double.TryParse(aux, out notebooks[i, j]) || notebooks[i, j] < 0 || notebooks[i, j] < 0)
                    {
                        MessageBox.Show("Entrada inválida!");
                        j--;
                    }
                    else
                    {

                        mediaprecos += notebooks[i, j];

                    }
                }
                listBox1.Items.Add(": Preço notebook   " + (i + 1) + " loja  1: " + (notebooks[i, 0]).ToString("N2") + "  loja 2: " + (notebooks[i, 1]).ToString("N2") + "  loja 3: " + (notebooks[i, 1]).ToString("N2"));
                listBox1.Items.Add("-----------------------------------");
                listBox1.Items.Add("Média Preços  : " + (mediaprecos / 3).ToString("N2"));
            }
        }
    }
}
